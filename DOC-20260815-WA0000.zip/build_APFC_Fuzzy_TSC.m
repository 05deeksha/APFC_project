%% BUILD SCRIPT: APFC with Fuzzy Logic TSC - Complete Model Construction
%  =========================================================================
%  This script builds the Simulink model APFC_Fuzzy_TSC.slx from scratch.
%  It creates the complete model programmatically including:
%    - Power circuit (AC source, RL load, measurements)
%    - 3-step thyristor-switched capacitor bank
%    - Power factor estimation logic
%    - Fuzzy Logic Controller with FIS design
%    - Switching logic with compare-to-constant blocks
%    - Scopes and logging
%  
%  USAGE: Run this script to rebuild the model from scratch.
%         >> build_APFC_Fuzzy_TSC
%  =========================================================================

clc; clear; close all;
fprintf('Building APFC Fuzzy TSC model...\n');

mdl = 'APFC_Fuzzy_TSC';

% Close if already open
if bdIsLoaded(mdl), close_system(mdl, 0); end
if exist([mdl '.slx'], 'file'), delete([mdl '.slx']); end

%% =========================================================================
%% STEP 1: CREATE FUZZY INFERENCE SYSTEM
%% =========================================================================
fprintf('  [1/8] Creating Fuzzy Inference System...\n');

fis = mamfis('Name','APFC_FLC');

% Input 1: Power Factor [0, 1]
fis = addInput(fis, [0 1], 'Name', 'PF');
fis = addMF(fis, 'PF', 'trapmf', [0 0 0.5 0.7], 'Name', 'Low');
fis = addMF(fis, 'PF', 'trimf', [0.5 0.75 0.95], 'Name', 'Medium');
fis = addMF(fis, 'PF', 'trapmf', [0.93 0.97 1 1], 'Name', 'High');

% Input 2: Rate of change of PF [-0.5, 0.5]
fis = addInput(fis, [-0.5 0.5], 'Name', 'dPF');
fis = addMF(fis, 'dPF', 'trapmf', [-0.5 -0.5 -0.1 0], 'Name', 'Negative');
fis = addMF(fis, 'dPF', 'trimf', [-0.05 0 0.05], 'Name', 'Zero');
fis = addMF(fis, 'dPF', 'trapmf', [0 0.1 0.5 0.5], 'Name', 'Positive');

% Output: Compensation Command [0, 3]
fis = addOutput(fis, [0 3], 'Name', 'CompCmd');
fis = addMF(fis, 'CompCmd', 'trimf', [0 0 0.5], 'Name', 'None');
fis = addMF(fis, 'CompCmd', 'trimf', [0.5 1 1.5], 'Name', 'Small');
fis = addMF(fis, 'CompCmd', 'trimf', [1.5 2 2.5], 'Name', 'Medium');
fis = addMF(fis, 'CompCmd', 'trapmf', [2.5 3 3 3], 'Name', 'Large');

% Rule Base (9 rules)
%   [Input1_MF Input2_MF Output_MF Weight Connection]
rules = [
    1 1 4 1 1;  % Low & Negative  => Large
    1 2 4 1 1;  % Low & Zero      => Large
    1 3 4 1 1;  % Low & Positive  => Large
    2 1 4 1 1;  % Medium & Negative => Large
    2 2 3 1 1;  % Medium & Zero    => Medium
    2 3 2 1 1;  % Medium & Positive => Small
    3 1 2 1 1;  % High & Negative  => Small
    3 2 2 1 1;  % High & Zero      => Small
    3 3 1 1 1;  % High & Positive  => None
];
fis = addRule(fis, rules);

% Save FIS to file and workspace
writeFIS(fis, 'APFC_FIS');
APFC_FIS = fis;
assignin('base', 'APFC_FIS', APFC_FIS);
fprintf('      FIS created: 2 inputs, 1 output, 9 rules\n');

%% =========================================================================
%% STEP 2: CREATE SIMULINK MODEL
%% =========================================================================
fprintf('  [2/8] Creating Simulink model...\n');

new_system(mdl);
open_system(mdl);

% Add powergui (required for Simscape Electrical)
add_block('powerlib/powergui', [mdl '/powergui'], 'Position', [20 20 120 70]);

%% =========================================================================
%% STEP 3: POWER CIRCUIT
%% =========================================================================
fprintf('  [3/8] Building power circuit...\n');

% AC Voltage Source (325V peak, 50Hz)
add_block('powerlib/Electrical Sources/AC Voltage Source', [mdl '/AC_Source'], ...
    'Position', [100 200 140 260], ...
    'Amplitude', '325', 'Frequency', '50', 'Phase', '0');

% Current Measurement
add_block('powerlib/Measurements/Current Measurement', [mdl '/I_Meas'], ...
    'Position', [200 210 240 250]);

% RL Load (R=20 Ohm, L=100mH - creates lagging power factor)
add_block('powerlib/Elements/Series RLC Branch', [mdl '/RL_Load'], ...
    'Position', [350 200 390 260], ...
    'BranchType', 'RL', 'Resistance', '20', 'Inductance', '100e-3');

% Voltage Measurement
add_block('powerlib/Measurements/Voltage Measurement', [mdl '/V_Meas'], ...
    'Position', [450 210 490 250]);

% Grounds
add_block('powerlib/Elements/Ground', [mdl '/Gnd1'], 'Position', [100 310 130 340]);
add_block('powerlib/Elements/Ground', [mdl '/Gnd2'], 'Position', [450 310 480 340]);

% Connect power circuit
add_line(mdl, 'AC_Source/1', 'I_Meas/1', 'autorouting', 'smart');
add_line(mdl, 'I_Meas/1', 'RL_Load/1', 'autorouting', 'smart');
add_line(mdl, 'RL_Load/2', 'V_Meas/1', 'autorouting', 'smart');
add_line(mdl, 'AC_Source/2', 'Gnd1/1', 'autorouting', 'smart');
add_line(mdl, 'V_Meas/2', 'Gnd2/1', 'autorouting', 'smart');

%% =========================================================================
%% STEP 4: CAPACITOR BANK WITH THYRISTOR SWITCHES
%% =========================================================================
fprintf('  [4/8] Building capacitor bank with switches...\n');

% Three capacitor banks with thyristor (ideal) switches
cap_values = {'40e-6', '30e-6', '30e-6'};  % 40uF, 30uF, 30uF
cap_labels = {'Cap1', 'Cap2', 'Cap3'};
sw_labels = {'Sw1', 'Sw2', 'Sw3'};

for k = 1:3
    y_offset = 350 + (k-1)*80;
    
    % Ideal Switch (thyristor model)
    add_block('spsIdealSwitchLib/Ideal Switch', [mdl '/' sw_labels{k}], ...
        'Position', [250 y_offset 290 y_offset+40]);
    
    % Capacitor (Series RLC Branch, C only)
    add_block('powerlib/Elements/Series RLC Branch', [mdl '/' cap_labels{k}], ...
        'Position', [370 y_offset 410 y_offset+40], ...
        'BranchType', 'C', 'Capacitance', cap_values{k});
    
    % Connect switch to capacitor
    add_line(mdl, [sw_labels{k} '/1'], [cap_labels{k} '/1'], 'autorouting', 'smart');
end

% Connect capacitor bank in parallel with load
add_block('powerlib/Elements/Ground', [mdl '/Gnd_Cap'], 'Position', [450 500 480 530]);

%% =========================================================================
%% STEP 5: POWER FACTOR ESTIMATION
%% =========================================================================
fprintf('  [5/8] Building PF estimation logic...\n');

% Power Measurement block
add_block('eePowerMeasurement/Power Measurement', [mdl '/P_Meas'], ...
    'Position', [550 200 620 260]);
set_param([mdl '/P_Meas'], 'K', '1', 'F', '50');

% PF = P / S where S = sqrt(P^2 + Q^2)
add_block('simulink/Math Operations/Math Function', [mdl '/Psq'], ...
    'Position', [680 180 720 210], 'Operator', 'square');
add_block('simulink/Math Operations/Math Function', [mdl '/Qsq'], ...
    'Position', [680 240 720 270], 'Operator', 'square');
add_block('simulink/Math Operations/Sum', [mdl '/SumPQ'], ...
    'Position', [760 200 790 250], 'Inputs', '++');
add_block('simulink/Math Operations/Math Function', [mdl '/SqrtS'], ...
    'Position', [820 210 860 240], 'Operator', 'sqrt');

% Bias to avoid division by zero
add_block('simulink/Math Operations/Sum', [mdl '/Eps_Bias'], ...
    'Position', [880 210 910 240], 'Inputs', '++');
add_block('simulink/Sources/Constant', [mdl '/Eps_Const'], ...
    'Position', [840 260 870 280], 'Value', '1e-10');

% Division: PF = P / S
add_block('simulink/Math Operations/Divide', [mdl '/PF_Div'], ...
    'Position', [940 190 970 230]);

% Saturation [0, 1]
add_block('simulink/Commonly Used Blocks/Saturation', [mdl '/PF_Sat'], ...
    'Position', [1000 195 1040 225], 'UpperLimit', '1', 'LowerLimit', '0');

% Connect PF estimation
add_line(mdl, 'P_Meas/1', 'Psq/1', 'autorouting', 'smart');
add_line(mdl, 'P_Meas/2', 'Qsq/1', 'autorouting', 'smart');
add_line(mdl, 'Psq/1', 'SumPQ/1', 'autorouting', 'smart');
add_line(mdl, 'Qsq/1', 'SumPQ/2', 'autorouting', 'smart');
add_line(mdl, 'SumPQ/1', 'SqrtS/1', 'autorouting', 'smart');
add_line(mdl, 'SqrtS/1', 'Eps_Bias/1', 'autorouting', 'smart');
add_line(mdl, 'Eps_Const/1', 'Eps_Bias/2', 'autorouting', 'smart');
add_line(mdl, 'P_Meas/1', 'PF_Div/1', 'autorouting', 'smart');
add_line(mdl, 'Eps_Bias/1', 'PF_Div/2', 'autorouting', 'smart');
add_line(mdl, 'PF_Div/1', 'PF_Sat/1', 'autorouting', 'smart');

%% =========================================================================
%% STEP 6: FUZZY LOGIC CONTROLLER
%% =========================================================================
fprintf('  [6/8] Adding Fuzzy Logic Controller...\n');

% Derivative of PF
add_block('simulink/Continuous/Derivative', [mdl '/dPF_Deriv'], ...
    'Position', [1060 280 1100 310]);

% Low-pass filter for derivative (smooth noise)
add_block('simulink/Continuous/Transfer Fcn', [mdl '/dPF_LPF'], ...
    'Position', [1120 278 1180 312], 'Numerator', '[1]', 'Denominator', '[0.005 1]');

% Saturation for dPF
add_block('simulink/Commonly Used Blocks/Saturation', [mdl '/dPF_Sat'], ...
    'Position', [1200 280 1240 310], 'UpperLimit', '0.5', 'LowerLimit', '-0.5');

% Mux: combine PF and dPF
add_block('simulink/Commonly Used Blocks/Mux', [mdl '/FLC_Mux'], ...
    'Position', [1270 200 1275 310], 'Inputs', '2');

% Fuzzy Logic Controller
add_block("fuzblock/Fuzzy Logic \nController", [mdl '/FLC'], ...
    'Position', [1310 220 1380 290], 'FIS', 'APFC_FIS');

% Connect FLC inputs
add_line(mdl, 'PF_Sat/1', 'dPF_Deriv/1', 'autorouting', 'smart');
add_line(mdl, 'dPF_Deriv/1', 'dPF_LPF/1', 'autorouting', 'smart');
add_line(mdl, 'dPF_LPF/1', 'dPF_Sat/1', 'autorouting', 'smart');
add_line(mdl, 'PF_Sat/1', 'FLC_Mux/1', 'autorouting', 'smart');
add_line(mdl, 'dPF_Sat/1', 'FLC_Mux/2', 'autorouting', 'smart');
add_line(mdl, 'FLC_Mux/1', 'FLC/1', 'autorouting', 'smart');

%% =========================================================================
%% STEP 7: SWITCHING LOGIC
%% =========================================================================
fprintf('  [7/8] Building switching logic...\n');

% Compare to constant blocks (thresholds for each capacitor)
thresholds = {'0.8', '1.4', '2.3'};
cmp_labels = {'Cmp1', 'Cmp2', 'Cmp3'};
dtc_labels = {'DTC1', 'DTC2', 'DTC3'};
gate_labels = {'Gate1', 'Gate2', 'Gate3'};

% Enable step (capacitors activate after initial transient)
add_block('simulink/Sources/Step', [mdl '/Enable_Step'], ...
    'Position', [1410 340 1440 360], ...
    'Time', '0.06', 'Before', '0', 'After', '1');

for k = 1:3
    y_off = 150 + (k-1)*60;
    
    % Compare to Constant
    add_block('simulink/Logic and Bit Operations/Compare To Constant', ...
        [mdl '/' cmp_labels{k}], ...
        'Position', [1420 y_off 1460 y_off+30], ...
        'const', thresholds{k}, 'relop', '>=');
    
    % Data Type Conversion (boolean to double)
    add_block('simulink/Commonly Used Blocks/Data Type Conversion', ...
        [mdl '/' dtc_labels{k}], ...
        'Position', [1490 y_off 1530 y_off+30], ...
        'OutDataTypeStr', 'double');
    
    % Product (gate with enable)
    add_block('simulink/Math Operations/Product', ...
        [mdl '/' gate_labels{k}], ...
        'Position', [1560 y_off 1590 y_off+35], 'Inputs', '2');
    
    % Connect
    add_line(mdl, 'FLC/1', [cmp_labels{k} '/1'], 'autorouting', 'smart');
    add_line(mdl, [cmp_labels{k} '/1'], [dtc_labels{k} '/1'], 'autorouting', 'smart');
    add_line(mdl, [dtc_labels{k} '/1'], [gate_labels{k} '/1'], 'autorouting', 'smart');
    add_line(mdl, 'Enable_Step/1', [gate_labels{k} '/2'], 'autorouting', 'smart');
    
    % Connect gate output to switch control port
    add_line(mdl, [gate_labels{k} '/1'], [sw_labels{k} '/2'], 'autorouting', 'smart');
end

%% =========================================================================
%% STEP 8: SCOPES AND LOGGING
%% =========================================================================
fprintf('  [8/8] Adding scopes and data logging...\n');

% PF To Workspace
add_block('simulink/Sinks/To Workspace', [mdl '/PF_Log'], ...
    'Position', [1080 195 1140 225], 'VariableName', 'PF_data', 'SaveFormat', 'Timeseries');
add_line(mdl, 'PF_Sat/1', 'PF_Log/1', 'autorouting', 'smart');

% FLC output To Workspace
add_block('simulink/Sinks/To Workspace', [mdl '/FLC_Log'], ...
    'Position', [1420 250 1480 280], 'VariableName', 'FLC_data', 'SaveFormat', 'Timeseries');
add_line(mdl, 'FLC/1', 'FLC_Log/1', 'autorouting', 'smart');

% Scope for PF
add_block('simulink/Sinks/Scope', [mdl '/Scope_PF'], ...
    'Position', [1100 130 1140 160]);
add_line(mdl, 'PF_Sat/1', 'Scope_PF/1', 'autorouting', 'smart');

% Display for PF
add_block('simulink/Sinks/Display', [mdl '/PF_Display'], ...
    'Position', [1100 90 1180 120]);
add_line(mdl, 'PF_Sat/1', 'PF_Display/1', 'autorouting', 'smart');

%% =========================================================================
%% CONFIGURE SOLVER
%% =========================================================================
set_param(mdl, 'Solver', 'ode23tb', 'StopTime', '1.0', ...
    'MaxStep', '5e-4', 'RelTol', '1e-3', 'AbsTol', '1e-4', ...
    'ZeroCrossControl', 'DisableAll', 'MaxConsecutiveZCs', '5000');

%% SAVE MODEL
save_system(mdl);
fprintf('\n  Model built and saved: %s.slx\n', mdl);
fprintf('  FIS saved: APFC_FIS.fis\n');
fprintf('  BUILD COMPLETE.\n');
fprintf('  Run "run_APFC_demo" to simulate and view results.\n');
