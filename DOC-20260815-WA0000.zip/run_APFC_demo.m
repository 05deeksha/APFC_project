%% AUTOMATIC POWER FACTOR CORRECTION USING THYRISTOR SWITCHED CAPACITOR
%% BANK WITH FUZZY LOGIC CONTROLLER - DEMONSTRATION SCRIPT
%  =========================================================================
%  Project  : M.Tech Power Electronics
%  Title    : Automatic Power Factor Correction Using Thyristor Switched
%             Capacitor Bank with Fuzzy Logic Controller
%  Tool     : MATLAB R2023b / Simulink / Simscape Electrical / Fuzzy Logic Toolbox
%  Model    : APFC_Fuzzy_TSC.slx
%  FIS File : APFC_FIS.fis
%  =========================================================================
%  HOW TO USE:
%  1. Open MATLAB and navigate to this folder
%  2. Run this script: >> run_APFC_demo
%  3. All figures and results will be generated automatically
%  =========================================================================

clc; clear; close all;
fprintf('=============================================================\n');
fprintf(' AUTOMATIC POWER FACTOR CORRECTION (APFC)\n');
fprintf(' Using Thyristor Switched Capacitor Bank\n');
fprintf(' with Fuzzy Logic Controller\n');
fprintf('=============================================================\n\n');

%% 1. LOAD THE FUZZY INFERENCE SYSTEM
fprintf('[1/6] Loading Fuzzy Inference System...\n');
APFC_FIS = readfis('APFC_FIS');
assignin('base', 'APFC_FIS', APFC_FIS);
fprintf('      FIS loaded: %s\n', APFC_FIS.Name);
fprintf('      Inputs:  %d (PF, dPF)\n', numel(APFC_FIS.Inputs));
fprintf('      Outputs: %d (CompCmd)\n', numel(APFC_FIS.Outputs));
fprintf('      Rules:   %d\n\n', numel(APFC_FIS.Rules));

%% 2. DISPLAY FIS DETAILS
fprintf('[2/6] Fuzzy Logic Controller Design:\n');
fprintf('      -----------------------------------------------\n');
fprintf('      Input 1: Power Factor (PF) [0, 1]\n');
for i = 1:numel(APFC_FIS.Inputs(1).MembershipFunctions)
    mf = APFC_FIS.Inputs(1).MembershipFunctions(i);
    fprintf('        MF%d: %-8s (%s) Params: [%s]\n', i, mf.Name, mf.Type, ...
        num2str(mf.Parameters, '%.2f '));
end
fprintf('      Input 2: Rate of Change of PF (dPF) [-0.5, 0.5]\n');
for i = 1:numel(APFC_FIS.Inputs(2).MembershipFunctions)
    mf = APFC_FIS.Inputs(2).MembershipFunctions(i);
    fprintf('        MF%d: %-8s (%s) Params: [%s]\n', i, mf.Name, mf.Type, ...
        num2str(mf.Parameters, '%.2f '));
end
fprintf('      Output: Compensation Command (CompCmd) [0, 3]\n');
for i = 1:numel(APFC_FIS.Outputs(1).MembershipFunctions)
    mf = APFC_FIS.Outputs(1).MembershipFunctions(i);
    fprintf('        MF%d: %-8s (%s) Params: [%s]\n', i, mf.Name, mf.Type, ...
        num2str(mf.Parameters, '%.2f '));
end
fprintf('\n');

%% 3. DISPLAY RULE BASE
fprintf('      FUZZY RULE BASE:\n');
fprintf('      -----------------------------------------------\n');
fprintf('      IF PF=Low  & dPF=Negative  THEN CompCmd=Large\n');
fprintf('      IF PF=Low  & dPF=Zero      THEN CompCmd=Large\n');
fprintf('      IF PF=Low  & dPF=Positive  THEN CompCmd=Large\n');
fprintf('      IF PF=Med  & dPF=Negative  THEN CompCmd=Large\n');
fprintf('      IF PF=Med  & dPF=Zero      THEN CompCmd=Medium\n');
fprintf('      IF PF=Med  & dPF=Positive  THEN CompCmd=Small\n');
fprintf('      IF PF=High & dPF=Negative  THEN CompCmd=Small\n');
fprintf('      IF PF=High & dPF=Zero      THEN CompCmd=Small\n');
fprintf('      IF PF=High & dPF=Positive  THEN CompCmd=None\n');
fprintf('      -----------------------------------------------\n\n');

%% 4. OPEN AND SIMULATE THE MODEL
fprintf('[3/6] Opening Simulink model: APFC_Fuzzy_TSC...\n');
mdl = 'APFC_Fuzzy_TSC';
open_system(mdl);
fprintf('      Model opened successfully.\n\n');

fprintf('[4/6] Running simulation (StopTime = 1.0s)...\n');
warning('off', 'all');
simOut = sim(mdl, 'StopTime', '1.0');
warning('on', 'all');
fprintf('      Simulation completed.\n\n');

%% 5. EXTRACT RESULTS
fprintf('[5/6] Extracting simulation results...\n');
pf_data = simOut.get('PF_data');
flc_data = simOut.get('FLC_data');

% Calculate key metrics
pf_initial = mean(pf_data.Data(pf_data.Time < 0.06));
pf_final = pf_data.Data(end);
pf_mean_ss = mean(pf_data.Data(pf_data.Time >= 0.3));
pf_max = max(pf_data.Data(pf_data.Time >= 0.1));
pf_min = min(pf_data.Data(pf_data.Time >= 0.3));

fprintf('\n');
fprintf('      ╔═══════════════════════════════════════════════╗\n');
fprintf('      ║       SIMULATION RESULTS SUMMARY             ║\n');
fprintf('      ╠═══════════════════════════════════════════════╣\n');
fprintf('      ║  Initial PF (uncorrected)  : %.4f           ║\n', pf_initial);
fprintf('      ║  Final PF (at t=1.0s)      : %.4f           ║\n', pf_final);
fprintf('      ║  Mean Steady-State PF      : %.4f           ║\n', pf_mean_ss);
fprintf('      ║  Peak PF achieved          : %.4f           ║\n', pf_max);
fprintf('      ║  PF Improvement            : %.1f%%            ║\n', (pf_mean_ss - pf_initial)/pf_initial*100);
fprintf('      ╚═══════════════════════════════════════════════╝\n\n');

%% 6. GENERATE PLOTS
fprintf('[6/6] Generating plots...\n\n');

% --- Figure 1: Power Factor Improvement ---
figure('Name', 'APFC Results - Power Factor', 'Position', [50 400 800 400]);
plot(pf_data.Time, pf_data.Data, 'b-', 'LineWidth', 1.5);
hold on;
yline(0.95, 'r--', 'Target PF = 0.95', 'LineWidth', 1.2, 'LabelHorizontalAlignment', 'left');
yline(pf_mean_ss, 'g--', sprintf('Mean PF = %.3f', pf_mean_ss), 'LineWidth', 1.2);
yline(pf_initial, 'k--', sprintf('Initial PF = %.3f', pf_initial), 'LineWidth', 1);
hold off;
xlabel('Time (s)', 'FontSize', 12);
ylabel('Power Factor', 'FontSize', 12);
title('Power Factor Correction using Fuzzy Logic TSC', 'FontSize', 14);
legend('Measured PF', 'Target', 'Mean Steady-State', 'Uncorrected', 'Location', 'southeast');
grid on;
ylim([0 1.1]);
set(gca, 'FontSize', 11);

% --- Figure 2: FLC Output & Switching ---
figure('Name', 'APFC Results - Controller Output', 'Position', [50 50 800 400]);
subplot(2,1,1);
plot(flc_data.Time, flc_data.Data, 'r-', 'LineWidth', 1.2);
hold on;
yline(0.8, 'b--', 'Cap1 ON', 'LineWidth', 0.8);
yline(1.4, 'g--', 'Cap2 ON', 'LineWidth', 0.8);
yline(2.3, 'm--', 'Cap3 ON', 'LineWidth', 0.8);
hold off;
xlabel('Time (s)', 'FontSize', 11);
ylabel('FLC Output', 'FontSize', 11);
title('Fuzzy Logic Controller Output', 'FontSize', 13);
legend('CompCmd', 'Threshold 1', 'Threshold 2', 'Threshold 3', 'Location', 'northeast');
grid on;
ylim([-0.2 3.5]);

subplot(2,1,2);
% Show switching states
cap1_on = double(flc_data.Data >= 0.8);
cap2_on = double(flc_data.Data >= 1.4);
cap3_on = double(flc_data.Data >= 2.3);
stairs(flc_data.Time, cap1_on * 1, 'b-', 'LineWidth', 1.5); hold on;
stairs(flc_data.Time, cap2_on * 2, 'g-', 'LineWidth', 1.5);
stairs(flc_data.Time, cap3_on * 3, 'r-', 'LineWidth', 1.5); hold off;
xlabel('Time (s)', 'FontSize', 11);
ylabel('Capacitor Bank Status', 'FontSize', 11);
title('Thyristor Switched Capacitor Bank States', 'FontSize', 13);
legend('Cap1 (40\muF)', 'Cap2 (30\muF)', 'Cap3 (30\muF)', 'Location', 'northeast');
yticks([0 1 2 3]);
yticklabels({'OFF', 'Cap1', 'Cap2', 'Cap3'});
grid on;
ylim([-0.2 3.5]);

% --- Figure 3: FIS Membership Functions ---
figure('Name', 'APFC Results - Fuzzy Membership Functions', 'Position', [900 400 700 500]);
subplot(3,1,1);
plotmf(APFC_FIS, 'input', 1);
title('Input 1: Power Factor (PF)', 'FontSize', 12);
xlabel('PF'); ylabel('Membership');

subplot(3,1,2);
plotmf(APFC_FIS, 'input', 2);
title('Input 2: Rate of Change (dPF)', 'FontSize', 12);
xlabel('dPF'); ylabel('Membership');

subplot(3,1,3);
plotmf(APFC_FIS, 'output', 1);
title('Output: Compensation Command', 'FontSize', 12);
xlabel('CompCmd'); ylabel('Membership');

% --- Figure 4: FIS Surface ---
figure('Name', 'APFC Results - FIS Control Surface', 'Position', [900 50 700 400]);
gensurf(APFC_FIS);
title('Fuzzy Logic Controller Surface', 'FontSize', 14);
xlabel('PF', 'FontSize', 11);
ylabel('dPF', 'FontSize', 11);
zlabel('Compensation Command', 'FontSize', 11);
colormap(jet);
colorbar;

% --- Figure 5: Before vs After Comparison ---
figure('Name', 'APFC Results - Comparison', 'Position', [450 200 600 400]);
bar_data = [pf_initial, pf_mean_ss, 0.95];
b = bar(bar_data, 0.5);
b.FaceColor = 'flat';
b.CData(1,:) = [0.8 0.2 0.2]; % Red for uncorrected
b.CData(2,:) = [0.2 0.7 0.2]; % Green for corrected
b.CData(3,:) = [0.2 0.2 0.8]; % Blue for target
xticklabels({'Uncorrected', 'With FLC-TSC', 'Target'});
ylabel('Power Factor', 'FontSize', 12);
title('Power Factor Correction Performance', 'FontSize', 14);
ylim([0 1.1]);
grid on;
set(gca, 'FontSize', 12);
text(1, pf_initial+0.03, sprintf('%.3f', pf_initial), 'HorizontalAlignment', 'center', 'FontSize', 11, 'FontWeight', 'bold');
text(2, pf_mean_ss+0.03, sprintf('%.3f', pf_mean_ss), 'HorizontalAlignment', 'center', 'FontSize', 11, 'FontWeight', 'bold');
text(3, 0.98, '0.950', 'HorizontalAlignment', 'center', 'FontSize', 11, 'FontWeight', 'bold');

fprintf('=============================================================\n');
fprintf(' ALL RESULTS GENERATED SUCCESSFULLY\n');
fprintf(' %d Figures created.\n', 5);
fprintf('=============================================================\n');
fprintf('\n SYSTEM PARAMETERS:\n');
fprintf('   AC Source      : 325V peak, 50 Hz\n');
fprintf('   Load           : R=20 Ohm, L=100 mH (lagging PF)\n');
fprintf('   Capacitor Bank : Cap1=40uF, Cap2=30uF, Cap3=30uF\n');
fprintf('   Controller     : Mamdani FIS, 9 rules\n');
fprintf('   Switching      : Thyristor (Ideal Switch model)\n');
fprintf('   Solver         : ode23tb, MaxStep=5e-4\n');
fprintf('=============================================================\n');
